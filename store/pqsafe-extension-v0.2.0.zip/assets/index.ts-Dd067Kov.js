chrome.runtime.onInstalled.addListener(()=>{console.log("PQSafe Wallet installed")});chrome.runtime.onMessage.addListener((e,r,n)=>(e.type==="PING"&&n({type:"PONG",version:"0.1.0"}),!1));
